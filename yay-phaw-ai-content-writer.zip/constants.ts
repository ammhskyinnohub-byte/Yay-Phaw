import { ContentStyle, SocialMediaChannel, ContentLength, Language } from './types';

export const LANGUAGE_OPTIONS = [
  { value: Language.ENGLISH, label: 'အင်္ဂလိပ်' },
  { value: Language.BURMESE, label: 'မြန်မာ' },
  { value: Language.THAI, label: 'ထိုင်း' },
  { value: Language.CHINESE, label: 'တရုတ်' },
];

export const CONTENT_STYLE_OPTIONS = [
  { value: ContentStyle.PROFESSIONAL, label: 'ကျွမ်းကျင်ပညာရှင်ဆန်ဆန်' },
  { value: ContentStyle.WITTY, label: 'ဉာဏ်ရွှင်ပြီး ဟာသဆန်ဆန်' },
  { value: ContentStyle.CASUAL, label: 'ပေါ့ပေါ့ပါးပါးနှင့် ဖော်ရွေစွာ' },
  { value: ContentStyle.INSPIRATIONAL, label: 'အားတက်ဖွယ်ရာ' },
  { value: ContentStyle.BOLD, label: 'ရဲရင့်ပြီး ယုံကြည်မှုရှိရှိ' },
  { value: ContentStyle.LUXURY, label: 'ဇိမ်ခံပစ္စည်းနှင့် ကျက်သရေရှိရှိ' },
];

export const SOCIAL_MEDIA_CHANNEL_OPTIONS = [
  { value: SocialMediaChannel.INSTAGRAM, label: 'Instagram' },
  { value: SocialMediaChannel.FACEBOOK, label: 'Facebook' },
  { value: SocialMediaChannel.TWITTER, label: 'Twitter (X)' },
  { value: SocialMediaChannel.LINKEDIN, label: 'LinkedIn' },
  { value: SocialMediaChannel.PINTEREST, label: 'Pinterest' },
];

export const CONTENT_LENGTH_OPTIONS = [
  { value: ContentLength.SHORT, label: 'တို (စာကြောင်း ၁-၂ ကြောင်း)' },
  { value: ContentLength.MEDIUM, label: 'အလယ်အလတ် (စာပိုဒ်တစ်ပိုဒ်)' },
  { value: ContentLength.LONG, label: 'အရှည် (စာပိုဒ်များစွာ)' },
];
