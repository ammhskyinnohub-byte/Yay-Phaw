
import React, { useState, useCallback } from 'react';
import { ContentStyle, SocialMediaChannel, ContentLength, GenerationParams, Language } from './types';
import { CONTENT_STYLE_OPTIONS, SOCIAL_MEDIA_CHANNEL_OPTIONS, CONTENT_LENGTH_OPTIONS, LANGUAGE_OPTIONS } from './constants';
import { generateContent } from './services/geminiService';
import ImageUploader from './components/ImageUploader';
import SelectInput from './components/SelectInput';
import ContentDisplay from './components/ContentDisplay';
import { SparklesIcon } from './components/icons/SparklesIcon';
import { GithubIcon } from './components/icons/GithubIcon';

const App: React.FC = () => {
  const [image, setImage] = useState<{ mimeType: string; data: string } | null>(null);
  const [brandName, setBrandName] = useState<string>('');
  const [language, setLanguage] = useState<Language>(Language.BURMESE);
  const [style, setStyle] = useState<ContentStyle>(ContentStyle.PROFESSIONAL);
  const [channel, setChannel] = useState<SocialMediaChannel>(SocialMediaChannel.FACEBOOK);
  const [length, setLength] = useState<ContentLength>(ContentLength.MEDIUM);
  const [generatedContent, setGeneratedContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const handleImageUpload = (file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = (reader.result as string).split(',')[1];
      setImage({ mimeType: file.type, data: base64String });
      setGeneratedContent('');
      setError('');
    };
    reader.onerror = () => {
      setError('Failed to read the image file.');
    };
    reader.readAsDataURL(file);
  };
  
  const handleGenerate = useCallback(async () => {
    if (!image) {
      setError('Please upload a product photo first.');
      return;
    }

    setIsLoading(true);
    setGeneratedContent('');
    setError('');

    try {
      const params: GenerationParams = { image, brandName, style, channel, length, language };
      const content = await generateContent(params);
      setGeneratedContent(content);
    } catch (e: any) {
      setError(`Failed to generate content: ${e.message}`);
    } finally {
      setIsLoading(false);
    }
  }, [image, brandName, style, channel, length, language]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <header className="text-center mb-8">
        <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight text-gray-800">
          Yay Phaw
        </h1>
        <p className="text-xl md:text-2xl text-gray-500 mt-2">သင်၏ ပရော်ဖက်ရှင်နယ် AI Content Writer</p>
      </header>
      
      <main className="w-full max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Panel: Controls */}
        <div className="bg-white/40 backdrop-blur-xl rounded-2xl p-8 shadow-lg border border-white/20">
          <h2 className="text-2xl font-bold mb-6 text-center text-gray-700">သင်၏အကြောင်းအရာကို စိတ်ကြိုက်ပြင်ဆင်ပါ</h2>
          <div className="space-y-6">
            <ImageUploader onImageUpload={handleImageUpload} />
            <div>
              <label htmlFor="brand-name" className="block text-sm font-medium text-gray-600 mb-2">ကုန်အမှတ်တံဆိပ် အမည် (ထည့်ချင်မှထည့်ပါ)</label>
              <input
                type="text"
                id="brand-name"
                value={brandName}
                onChange={(e) => setBrandName(e.target.value)}
                placeholder="သင်၏ ကုန်အမှတ်တံဆိပ်"
                className="block w-full bg-white/60 border border-white/70 rounded-md shadow-sm py-2 px-3 text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-400 sm:text-sm"
              />
            </div>
            <SelectInput 
              label="ဘာသာစကား"
              value={language}
              onChange={(e) => setLanguage(e.target.value as Language)}
              options={LANGUAGE_OPTIONS}
            />
            <SelectInput 
              label="အကြောင်းအရာ ပုံစံ"
              value={style}
              onChange={(e) => setStyle(e.target.value as ContentStyle)}
              options={CONTENT_STYLE_OPTIONS}
            />
            <SelectInput 
              label="လူမှုကွန်ရက်"
              value={channel}
              onChange={(e) => setChannel(e.target.value as SocialMediaChannel)}
              options={SOCIAL_MEDIA_CHANNEL_OPTIONS}
            />
            <SelectInput 
              label="အကြောင်းအရာ အရှည်"
              value={length}
              onChange={(e) => setLength(e.target.value as ContentLength)}
              options={CONTENT_LENGTH_OPTIONS}
            />
            <button
              onClick={handleGenerate}
              disabled={isLoading || !image}
              className="w-full flex items-center justify-center bg-blue-500 hover:bg-blue-600 disabled:bg-blue-400/50 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-xl transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-300"
            >
              <SparklesIcon className="w-6 h-6 mr-2" />
              {isLoading ? 'ဖန်တီးနေသည်...' : 'အကြောင်းအရာ ဖန်တီးပါ'}
            </button>
          </div>
        </div>
        
        {/* Right Panel: Display */}
        <div className="bg-white/40 backdrop-blur-xl rounded-2xl p-8 shadow-lg border border-white/20">
          <h2 className="text-2xl font-bold mb-6 text-center text-gray-700">ဖန်တီးထားသော အကြောင်းအရာ</h2>
          <ContentDisplay 
            content={generatedContent}
            isLoading={isLoading}
            error={error}
            hasImage={!!image}
          />
        </div>
      </main>

       <footer className="text-center mt-12 text-gray-500">
          <p>ကိုဟိန်းမှ ပြုလုပ်သည်</p>
        </footer>
    </div>
  );
};

export default App;