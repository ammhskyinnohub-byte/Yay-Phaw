import React, { useState } from 'react';
import { ClipboardIcon } from './icons/ClipboardIcon';
import { CheckIcon } from './icons/CheckIcon';

interface ContentDisplayProps {
  content: string;
  isLoading: boolean;
  error: string;
  hasImage: boolean;
}

const LoadingSpinner: React.FC = () => (
  <div className="flex flex-col items-center justify-center h-full text-center">
    <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-500"></div>
    <p className="mt-4 text-gray-600">Yay Phaw စဉ်းစားနေသည်...</p>
  </div>
);

const InitialState: React.FC = () => (
    <div className="flex flex-col items-center justify-center h-full text-center text-gray-500">
        <div className="w-16 h-16 mb-4 text-gray-400">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 0 0 1.5-.189m-1.5.189a6.01 6.01 0 0 1-1.5-.189m3.75 7.478a12.06 12.06 0 0 1-4.5 0m3.75 2.311a7.5 7.5 0 0 1-7.5 0c-1.421-.492-2.682-.998-3.75-1.625M12 18c-2.28 0-4.516.21-6.533.533m6.533-.533c2.017.323 4.253.533 6.533.533m-13.066 0c-1.068-.627-2.329-1.133-3.75-1.625m2.632 7.632c.943.468 1.956.846 3.031 1.152" />
            </svg>
        </div>
        <h3 className="text-lg font-semibold text-gray-600">သင်၏ အကြောင်းအရာသည် ဤနေရာတွင် ပေါ်လာပါမည်</h3>
        <p className="mt-1 text-sm">စတင်ရန် ဓာတ်ပုံတစ်ပုံတင်ပြီး သင်၏စိတ်ကြိုက်ရွေးချယ်မှုများကို သတ်မှတ်ပါ။</p>
    </div>
);


const ContentDisplay: React.FC<ContentDisplayProps> = ({ content, isLoading, error, hasImage }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (!content) return;
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (isLoading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return (
        <div className="flex flex-col items-center justify-center h-full text-center text-red-500">
            <div className="w-16 h-16 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
                </svg>
            </div>
            <h3 className="text-lg font-semibold">အမှားတစ်ခု ဖြစ်ပွားခဲ့သည်</h3>
            <p className="mt-1 text-sm">{error}</p>
        </div>
    );
  }

  if (!content) {
    return <InitialState />;
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-grow overflow-y-auto mb-4 pr-2">
        <pre className="whitespace-pre-wrap font-sans text-base text-gray-800">
          {content}
        </pre>
      </div>
      <button
        onClick={handleCopy}
        disabled={copied}
        className={`w-full flex items-center justify-center font-bold py-2 px-4 rounded-xl transition-all duration-300 focus:outline-none focus:ring-4 ${
          copied 
            ? 'bg-green-500 text-white focus:ring-green-300 cursor-default' 
            : 'bg-blue-500 hover:bg-blue-600 text-white focus:ring-blue-300'
        }`}
        aria-label="Copy content to clipboard"
      >
        {copied ? (
          <>
            <CheckIcon className="w-5 h-5 mr-2" />
            <span>ကူးယူပြီးပါပြီ!</span>
          </>
        ) : (
          <>
            <ClipboardIcon className="w-5 h-5 mr-2" />
            <span>အကြောင်းအရာ ကူးယူပါ</span>
          </>
        )}
      </button>
    </div>
  );
};

export default ContentDisplay;
