
import { GoogleGenAI } from "@google/genai";
import type { GenerationParams } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateContent(params: GenerationParams): Promise<string> {
  const { image, brandName, style, channel, length, language } = params;

  const model = 'gemini-2.5-flash';

  const prompt = `You are a world-class professional social media content writer. 
  Your task is to create a compelling post based on the provided product image.
  
  **Instructions:**
  - **Language:** Write the output in ${language}.
  - **Brand Name:** ${brandName ? `Naturally incorporate the brand name "${brandName}" into the content.` : 'No brand name provided.'}
  - **Platform:** ${channel}
  - **Tone of Voice:** ${style}
  - **Content Length:** ${length}
  - **Goal:** Create engaging content that highlights the product's features and benefits, encouraging user interaction (likes, comments, shares) and driving interest.
  - **Formatting:** Use appropriate formatting for the target platform (e.g., hashtags for Instagram, professional tone for LinkedIn).
  - **Crucial Rule 1:** Do NOT use markdown for bolding. For example, do not use '**' characters in your response.
  - **Crucial Rule 2:** Do NOT mention your name or persona in the output. The content should be ready to be posted directly.

  Analyze the product in the image and write the content.`;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          { inlineData: { mimeType: image.mimeType, data: image.data } },
          { text: prompt }
        ]
      },
    });
    
    return response.text;
  } catch (error) {
    console.error('Error generating content with Gemini:', error);
    throw new Error('The AI model failed to generate a response. Please try again.');
  }
}