
export enum Language {
  ENGLISH = 'English',
  BURMESE = 'Burmese',
  THAI = 'Thai',
  CHINESE = 'Chinese',
}

export enum ContentStyle {
  PROFESSIONAL = 'Professional',
  WITTY = 'Witty & Humorous',
  CASUAL = 'Casual & Friendly',
  INSPIRATIONAL = 'Inspirational',
  BOLD = 'Bold & Confident',
  LUXURY = 'Luxury & Elegant',
}

export enum SocialMediaChannel {
  INSTAGRAM = 'Instagram',
  FACEBOOK = 'Facebook',
  TWITTER = 'Twitter (X)',
  LINKEDIN = 'LinkedIn',
  PINTEREST = 'Pinterest',
}

export enum ContentLength {
  SHORT = 'Short (1-2 sentences)',
  MEDIUM = 'Medium (a paragraph)',
  LONG = 'Long (multiple paragraphs)',
}

export interface GenerationParams {
  image: {
    mimeType: string;
    data: string;
  };
  brandName: string;
  style: ContentStyle;
  channel: SocialMediaChannel;
  length: ContentLength;
  language: Language;
}